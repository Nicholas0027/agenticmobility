"""Agent kinds: the unit of extension for new agentic entities.

A *kind* describes one type of agent in the mobility system -- travellers,
ride vehicles, buses, charging stations, the network operator, or anything a
plugin adds. A kind declares

* its **agency vocabulary** (permissions and how they accumulate over levels);
* its **decision points** (``due``), the **observation** shown at each, and the
  **default action** that applies when the agent has no authority there;
* how a validated decision changes the world (``apply``), how interactions are
  settled (``resolve``) and how the entity evolves physically (``physics``).

The engine treats every kind identically: all due agents observe the same
state, decisions are produced by each agent's decision model (rule, algorithm,
LLM, remote, ...), and actions are applied kind by kind in a fixed order.
"""
from __future__ import annotations

import math
from typing import Optional

from ..actions import ActionSpec, Decision, Param
from ..agency import AgencySpec
from ..network import current_weight, free_flow_weight
from ..observation import Observation
from ..registry import Registry

KINDS = Registry("agent kind")


def register_kind(name: str):
    return KINDS.register(name)


class Kind:
    name = "kind"
    side = "machine"                 # "human" or "machine": which LLM switch of the 2x2 design it belongs to
    title = ""
    role_prompt = ""                 # how an LLM decision model is told who it is
    objective = ""                   # what an agent of this kind is told to pursue: a sentence in its state (see ``goal``)
    triggers: dict = {}              # trigger -> explanation (used in prompts and docs)
    actions: dict = {}               # action -> explanation
    agency: Optional[AgencySpec] = None
    drives = False                   # finds its own way through traffic (see agmsim.mechanisms.TrafficKnowledge)

    def __init__(self, sim):
        self.sim = sim
        self.world = sim.world
        self.cfg = getattr(sim.cfg.agents, self.name, None)

    # ------------------------------------------------------------------ life-cycle hooks

    def setup(self) -> list[str]:
        """Create this kind's entities in the world and return the ids of its agents."""
        return []

    def begin_tick(self) -> None:
        """Exogenous updates at the start of a tick (new needs, timers)."""

    def due(self) -> list[tuple[str, str]]:
        """Decision points of this tick as ``(agent_id, trigger)``, in agent-id order."""
        return []

    def authority(self, agent_id: str, trigger: str) -> bool:
        """Does the agent's agency give it a say at this decision point?"""
        return True

    def observe(self, agent_id: str, trigger: str) -> Optional[Observation]:
        """Build the observation, or None if there is nothing to decide."""
        raise NotImplementedError

    def nothing_to_decide(self, agent_id: str, trigger: str) -> None:
        """Called when ``observe`` returned None."""

    def apply(self, rec) -> None:
        """Apply a validated decision (``rec.decision``) to the world."""

    def resolve(self) -> None:
        """Settle interactions after all actions of the tick were applied."""

    def physics(self) -> None:
        """Advance this kind's entities by one time step."""

    def frame(self) -> list:
        """Compact snapshot for visualisation."""
        return []

    def on_the_road(self):
        """For kinds that drive: the entities that are out on the network now, in id order."""
        return ()

    def remember(self, rec) -> dict:
        """How a decision of the agent's own goes into its memory.

        An entry is read later, away from the observation it was taken on, so it has to say what was
        done in words that still mean something then: an option's number does not, what the option was does.
        """
        item = {"trigger": rec.trigger, "did": rec.decision.action}
        if rec.decision.args:
            item["args"] = dict(rec.decision.args)
        if rec.result:
            item["result"] = rec.result
        return item

    # ------------------------------------------------------------------ helpers

    def allows(self, agent_id: str, permission: str) -> bool:
        return self.sim.agency[agent_id].allows(permission)

    def own_goal(self, agent_id: str = "") -> str:
        """The kind's own sentence for what this agent pursues (a kind may make it depend on the agent's authority)."""
        return self.objective

    def goal(self, agent_id: str = "") -> str:
        """What the agent is told to pursue, as shown in its state at every decision: the scenario's sentence
        (``agents.<kind>.objective``) if it has one, else the kind's own. Empty: the kind states none."""
        told = (getattr(self.cfg, "objective", None) or "").strip()
        return told or self.own_goal(agent_id)

    def spec(self, action: str, *params: Param) -> ActionSpec:
        return ActionSpec(action, self.actions[action], tuple(params))

    def obs(self, agent_id, trigger, state, context, actions, default: Decision, aux=None) -> Observation:
        w = self.world
        if w.environment:                    # e.g. the weather: something every agent can see for itself
            context = {**context, "environment": dict(w.environment)}
        return Observation(agent_id, self.name, w.tick, w.time_s + w.clock0, trigger, state, context,
                           tuple(actions), default, aux or {}, self.sim.memories.of(agent_id))


# --------------------------------------------------------------------------- movement


def update_flows(sim) -> None:
    """Congestion for this tick from where every vehicle is: a car counts once, a bus twice."""
    w, net_cfg = sim.world, sim.cfg.network
    if not net_cfg.congestion:
        return
    counts: dict = {}
    for v in w.vehicles.values():
        if v.link is not None:
            counts[v.link] = counts.get(v.link, 0) + 1
    for bus in w.buses.values():
        if bus.link is not None:
            counts[bus.link] = counts.get(bus.link, 0) + 2
    for cab in w.cabs.values():
        if cab.link is not None:
            counts[cab.link] = counts.get(cab.link, 0) + 1
    w.net.set_flows(counts, net_cfg.jam_spacing_m, net_cfg.capacity_scale)


def _may_cross(line, m, gated: bool) -> bool:
    """May the mover leave this link now? Movers that have to stop wait in arrival order for the light."""
    if not gated:                       # the trip ends here, or the mover has priority: no green needed
        if m.queued:
            line.queue.remove(m)
        m.queued = m.go = False
        return True
    if m.go:                            # released by the traffic light in this tick
        m.go = False
        return True
    if m.queued:
        return False
    if line.green and not line.queue and line.credit >= 1.0:
        line.credit -= 1.0
        line.passed += 1
        return True
    line.queue.append(m)
    m.queued = True
    return False


def advance(net, m, dt: float, factor: float = 1.0, own_lane: bool = False, preempt: bool = False) -> tuple[float, bool]:
    """Move ``m`` along ``m.path`` for ``dt`` seconds.

    ``m`` is any entity with ``node``, ``link``, ``offset`` and ``path``. With
    ``own_lane`` the mover is unaffected by congestion (but still by incidents).
    At a signalised junction the mover stops at the end of its link until the
    light lets it through, unless its trip ends there or ``preempt`` is set.
    Returns the metres travelled and whether the end of the path was reached.
    """
    budget = dt
    moved = 0.0
    while m.path and budget > 1e-9:
        link = net.links[m.path[0]]
        if m.link is None:
            m.link, m.offset = link.id, 0.0
        speed = (link.cur_speed / link.flow if own_lane else link.cur_speed) * factor
        remaining = link.length - m.offset
        need = remaining / speed
        if need <= budget + 1e-9:
            line = net.stop_lines.get(link.id)
            if line is not None and not _may_cross(line, m, len(m.path) > 1 and not preempt):
                moved += remaining
                m.offset = link.length
                break
            moved += remaining
            budget -= need
            m.node, m.link, m.offset = link.v, None, 0.0
            m.path.pop(0)
        else:
            step = speed * budget
            m.offset += step
            moved += step
            budget = 0.0
    return moved, (not m.path and m.link is None)


def path_to(world, m, node: int, dynamic: bool = False, weight=None) -> list[int]:
    """Link sequence from the mover's position to ``node`` (finishing the current link first).

    The fastest route without traffic, with traffic as it is now (``dynamic``), or with the travel times
    ``weight`` gives -- what the mover itself knows.
    """
    net = world.net
    start = net.links[m.link].v if m.link is not None else m.node
    if weight is None or weight is free_flow_weight or weight is current_weight:
        rest = net.route(start, node, dynamic or weight is current_weight).links
    else:
        rest = net.fastest(start, node, weight).links
    return ([m.link] if m.link is not None else []) + list(rest)


def route_memory(rec) -> dict:
    """A choice between routes, for the agent's memory: the routes by what they were, not by their numbers
    (route 0 is whichever route the vehicle is on at that moment)."""
    rows = rec.obs.context["routes"]
    chosen = rows[rec.decision.args["route"]]

    def what(row):                          # with which route it was: without that a later look cannot tell routes apart
        out = {"name": row["name"]} if "name" in row else {}
        out.update(eta_min=row["eta_min"], km=row["km"])
        if "via_nodes" in row:
            out["via_nodes"] = row["via_nodes"]
        return out

    if chosen["route"] != 0:
        return {"trigger": rec.trigger, "did": "changed route", "left_route": what(rows[0]), "took_route": what(chosen)}
    item = {"trigger": rec.trigger, "did": "kept route", "route": what(rows[0])}
    if len(rows) > 1:
        item["quickest_other_route"] = what(min(rows[1:], key=lambda row: (row["eta_min"], row["route"])))
    return item


def name_routes(net, rows: list, routes: list, start: int) -> None:
    """Give every listed route the junctions it passes, from ``start`` on: what makes it the route it is."""
    for row, route in zip(rows, routes):
        row["via_nodes"] = [start] + [net.links[lid].v for lid in route.links]


#: Shown with routes that have names: what a name is.
ROUTE_NAMES = ("a name stands for one way to your destination: routes that share a name are variants of it. "
               "A name means the same at every decision and in your memory; a route's number does not")


def label_routes(sim, agent_id: str, rows: list, routes: list, destination: int, context: dict) -> None:
    """Give every listed route the name of its way: what a route can be recognised by at a later decision."""
    for row, name in zip(rows, sim.route_names.give(agent_id, routes, destination)):
        rest = {key: row.pop(key) for key in list(row) if key != "route"}
        row.update(name=name, **rest)
    context["route_names"] = ROUTE_NAMES


def known_path(sim, kind, m, node: int) -> list[int]:
    """The route to ``node`` that a driving agent takes: by what it knows of traffic, if it uses that at all."""
    if not kind.informed(m):
        return path_to(sim.world, m, node)
    return path_to(sim.world, m, node, weight=sim.traffic.weight(kind.name, m))


def known_eta(sim, kind, m, node: int) -> float:
    """Seconds to ``node`` as the driving agent reckons them."""
    w = sim.world
    if not kind.informed(m):
        return w.eta(m, node)
    weight = sim.traffic.weight(kind.name, m)
    if weight is current_weight or weight is free_flow_weight:
        return w.eta(m, node, weight is current_weight)
    anchor, _, lead_cur, _ = w.anchor(m)
    return lead_cur + w.net._dijkstra(anchor, weight, target=node)[0].get(node, math.inf)
